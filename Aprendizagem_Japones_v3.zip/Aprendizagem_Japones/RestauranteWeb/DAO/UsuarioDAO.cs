﻿using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class UsuarioDAO : PadraoDAO<UsuarioViewModel>
    {
        protected override void SetTabela()
        {
            Tabela = "Usuarios";
        }

        protected override SqlParameter[] CriaParametros(UsuarioViewModel model)
        {
            return new SqlParameter[]
            {
                new SqlParameter("@id", model.Id),
                new SqlParameter("@login", model.Login),
                new SqlParameter("@senha", model.Senha),
                new SqlParameter("@perfil", model.Perfil)
            };
        }

        protected override UsuarioViewModel MontaModel(DataRow registro)
        {
            UsuarioViewModel usuario = new UsuarioViewModel();

            if (registro.Table.Columns.Contains("Id") && registro["Id"] != DBNull.Value)
                usuario.Id = Convert.ToInt32(registro["Id"]);
            else if (registro.Table.Columns.Contains("id") && registro["id"] != DBNull.Value)
                usuario.Id = Convert.ToInt32(registro["id"]);

            if (registro.Table.Columns.Contains("Login") && registro["Login"] != DBNull.Value)
                usuario.Login = registro["Login"].ToString() ?? string.Empty;
            else if (registro.Table.Columns.Contains("login") && registro["login"] != DBNull.Value)
                usuario.Login = registro["login"].ToString() ?? string.Empty;

            if (registro.Table.Columns.Contains("Senha") && registro["Senha"] != DBNull.Value)
                usuario.Senha = registro["Senha"].ToString() ?? string.Empty;
            else if (registro.Table.Columns.Contains("senha") && registro["senha"] != DBNull.Value)
                usuario.Senha = registro["senha"].ToString() ?? string.Empty;

            if (registro.Table.Columns.Contains("Perfil") && registro["Perfil"] != DBNull.Value)
                usuario.Perfil = registro["Perfil"].ToString() ?? string.Empty;
            else if (registro.Table.Columns.Contains("perfil") && registro["perfil"] != DBNull.Value)
                usuario.Perfil = registro["perfil"].ToString() ?? string.Empty;

            return usuario;
        }

        /// <summary>
        /// Valida login e senha via Stored Procedure parametrizada.
        /// </summary>
        public UsuarioViewModel? Autenticar(string login, string senha)
        {
            SqlParameter[] parametros = new SqlParameter[]
            {
                new SqlParameter("@login", login),
                new SqlParameter("@senha", senha)
            };

            DataTable tabela = HelperDAO.ExecutaProcSelect("spAutenticaUsuario", parametros);

            if (tabela.Rows.Count == 0)
                return null;

            return MontaModel(tabela.Rows[0]);
        }
    }
}