using System;
using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class ClienteDAO : PadraoDAO<ClienteViewModel>
    {
        protected override SqlParameter[] CriaParametros(ClienteViewModel model)
        {
            SqlParameter[] parametros =
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("nome", model.Nome),
                new SqlParameter("cpf", model.Cpf),
                new SqlParameter("telefone", model.Telefone),
                new SqlParameter("email", string.IsNullOrWhiteSpace(model.Email) ? (object)DBNull.Value : model.Email)
            };
            return parametros;
        }

        protected override ClienteViewModel MontaModel(DataRow registro)
        {
            return new ClienteViewModel()
            {
                Id = Convert.ToInt32(registro["id"]),
                Nome = registro["nome"].ToString(),
                Cpf = registro["cpf"].ToString(),
                Telefone = registro["telefone"].ToString(),
                Email = registro["email"] == DBNull.Value ? null : registro["email"].ToString()
            };
        }

        protected override void SetTabela()
        {
            Tabela = "Clientes";
            ChaveIdentity = true;
        }

        public ClienteViewModel ConsultaPorCpf(string cpf)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("cpf", cpf)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsultaClientePorCpf", p);
            return tabela.Rows.Count == 0 ? null : MontaModel(tabela.Rows[0]);
        }
        public bool EmUso(int id)
        {
            return HelperDAO.RegistroEmUso("Clientes", id);
        }
    }
}
