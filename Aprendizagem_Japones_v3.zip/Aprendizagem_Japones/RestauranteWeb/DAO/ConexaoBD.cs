using System.Data.SqlClient;

namespace RestauranteWeb.DAO
{
    public static class ConexaoBD
    {
        public static string StringConexao { get; set; }
        public static SqlConnection GetConexao()
        {
            SqlConnection conexao = new SqlConnection(StringConexao);
            conexao.Open();
            return conexao;
        }
    }   
}
