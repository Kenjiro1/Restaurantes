using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class CardapioDAO : PadraoDAO<ItemCardapioViewModel>
    {
        protected override SqlParameter[] CriaParametros(ItemCardapioViewModel model)
        {
            SqlParameter[] parametros =
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("nome", model.Nome),
                new SqlParameter("descricao", string.IsNullOrWhiteSpace(model.Descricao) ? (object)DBNull.Value : model.Descricao),
                new SqlParameter("categoria", model.Categoria),
                new SqlParameter("preco", SqlDbType.Decimal) { Precision = 10, Scale = 2, Value = model.Preco },
                new SqlParameter("ativo", model.Ativo)
            };
            return parametros;
        }

        protected override ItemCardapioViewModel MontaModel(DataRow registro)
        {
            return new ItemCardapioViewModel()
            {
                Id = Convert.ToInt32(registro["id"]),
                Nome = registro["nome"].ToString(),
                Descricao = registro["descricao"] == DBNull.Value ? null : registro["descricao"].ToString(),
                Categoria = Convert.ToInt32(registro["categoria"]),
                Preco = Convert.ToDecimal(registro["preco"]),
                Ativo = Convert.ToBoolean(registro["ativo"])
            };
        }

        protected override void SetTabela()
        {
            Tabela = "Cardapio";
            ChaveIdentity = true;
        }
        public List<ItemCardapioViewModel> ListagemAtivos()
        {
            var tabela = HelperDAO.ExecutaProcSelect("spListagemCardapioAtivos", null);
            List<ItemCardapioViewModel> lista = new List<ItemCardapioViewModel>();
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaModel(registro));
            return lista;
        }
        public bool EmUso(int id)
        {
            return HelperDAO.RegistroEmUso("Cardapio", id);
        }
    }
}
