using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class ConsultaDAO
    {
        public List<ItemMaisVendidoViewModel> ItensMaisVendidos(DateTime? dataInicial, DateTime? dataFinal, int top)
        {
            var p = new SqlParameter[]
            {
                HelperDAO.ParametroDataInicial(dataInicial),
                HelperDAO.ParametroDataFinal(dataFinal),
                new SqlParameter("top", top)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spItensMaisVendidos", p);
            List<ItemMaisVendidoViewModel> lista = new List<ItemMaisVendidoViewModel>();
            foreach (DataRow r in tabela.Rows)
            {
                lista.Add(new ItemMaisVendidoViewModel()
                {
                    CardapioId = Convert.ToInt32(r["cardapioId"]),
                    Nome = r["nome"].ToString(),
                    QuantidadeVendida = Convert.ToInt32(r["quantidadeVendida"]),
                    Faturamento = Convert.ToDecimal(r["faturamento"])
                });
            }
            return lista;
        }

        public List<FaturamentoFuncionarioViewModel> FaturamentoPorFuncionario(DateTime? dataInicial, DateTime? dataFinal)
        {
            var p = new SqlParameter[]
            {
                HelperDAO.ParametroDataInicial(dataInicial),
                HelperDAO.ParametroDataFinal(dataFinal)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spFaturamentoPorFuncionario", p);
            List<FaturamentoFuncionarioViewModel> lista = new List<FaturamentoFuncionarioViewModel>();
            foreach (DataRow r in tabela.Rows)
            {
                lista.Add(new FaturamentoFuncionarioViewModel()
                {
                    FuncionarioId = Convert.ToInt32(r["funcionarioId"]),
                    Nome = r["nome"].ToString(),
                    QtdPedidos = Convert.ToInt32(r["qtdPedidos"]),
                    Faturamento = Convert.ToDecimal(r["faturamento"])
                });
            }
            return lista;
        }
    }
}
