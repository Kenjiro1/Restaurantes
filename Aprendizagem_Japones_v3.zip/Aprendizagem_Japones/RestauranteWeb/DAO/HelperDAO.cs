using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace RestauranteWeb.DAO
{
    public static class HelperDAO
    {
        public static int ExecutaProc(string nomeProc, SqlParameter[] parametros, bool consultaUltimoIdentity = false)
        {
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            {
                using (SqlCommand comando = new SqlCommand(nomeProc, conexao))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    if (parametros != null)
                        comando.Parameters.AddRange(parametros);
                    comando.ExecuteNonQuery();

                    if (consultaUltimoIdentity)
                    {
                        comando.Parameters.Clear();
                        comando.CommandType = CommandType.Text;
                        comando.CommandText = "select isnull(@@IDENTITY, 0)";
                        return Convert.ToInt32(comando.ExecuteScalar());
                    }
                    return 0;
                }
            }
        }

        public static DataTable ExecutaProcSelect(string nomeProc, SqlParameter[] parametros)
        {
            using (SqlConnection conexao = ConexaoBD.GetConexao())
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(nomeProc, conexao))
                {
                    if (parametros != null)
                        adapter.SelectCommand.Parameters.AddRange(parametros);
                    adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataTable tabela = new DataTable();
                    adapter.Fill(tabela);
                    return tabela;
                }
            }
        }
        public static bool RegistroEmUso(string entidade, int id)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("entidade", entidade),
                new SqlParameter("id", id)
            };
            var tabela = ExecutaProcSelect("spEmUso", p);
            return Convert.ToInt32(tabela.Rows[0][0]) > 0;
        }

        // ---------- Filtros de período usados nas consultas ----------

        /// <summary>Sem data informada = desde o menor valor de datetime aceito pelo SQL Server</summary>
        public static SqlParameter ParametroDataInicial(DateTime? data)
        {
            return new SqlParameter("dataInicial", SqlDbType.DateTime)
            {
                Value = data.HasValue ? data.Value.Date : SqlDateTime.MinValue.Value
            };
        }

        /// <summary>
        /// A data final é EXCLUSIVA nas procedures: enviamos o dia seguinte ao informado,
        /// para que o dia inteiro escolhido entre na consulta.
        /// </summary>
        public static SqlParameter ParametroDataFinal(DateTime? data)
        {
            return new SqlParameter("dataFinal", SqlDbType.DateTime)
            {
                Value = data.HasValue ? data.Value.Date.AddDays(1) : SqlDateTime.MaxValue.Value
            };
        }
    }
}
