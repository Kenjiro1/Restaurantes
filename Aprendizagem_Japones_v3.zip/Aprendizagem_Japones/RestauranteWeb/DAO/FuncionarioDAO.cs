using System;
using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class FuncionarioDAO : PadraoDAO<FuncionarioViewModel>
    {
        protected override SqlParameter[] CriaParametros(FuncionarioViewModel model)
        {
            SqlParameter[] parametros =
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("nome", model.Nome),
                new SqlParameter("cargo", model.Cargo),
                new SqlParameter("telefone", model.Telefone),
                new SqlParameter("dataAdmissao", SqlDbType.DateTime) { Value = model.DataAdmissao }
            };
            return parametros;
        }

        protected override FuncionarioViewModel MontaModel(DataRow registro)
        {
            return new FuncionarioViewModel()
            {
                Id = Convert.ToInt32(registro["id"]),
                Nome = registro["nome"].ToString(),
                Cargo = registro["cargo"].ToString(),
                Telefone = registro["telefone"].ToString(),
                DataAdmissao = Convert.ToDateTime(registro["dataAdmissao"])
            };
        }

        protected override void SetTabela()
        {
            Tabela = "Funcionarios";
            ChaveIdentity = true;
        }
        public bool EmUso(int id)
        {
            return HelperDAO.RegistroEmUso("Funcionarios", id);
        }
    }
}
