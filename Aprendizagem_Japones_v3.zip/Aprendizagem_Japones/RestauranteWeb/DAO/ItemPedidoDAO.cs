using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class ItemPedidoDAO : PadraoDAO<ItemPedidoViewModel>
    {
        protected override SqlParameter[] CriaParametros(ItemPedidoViewModel model)
        {
            SqlParameter[] parametros =
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("pedidoId", model.PedidoId),
                new SqlParameter("cardapioId", model.CardapioId),
                new SqlParameter("quantidade", model.Quantidade),
                new SqlParameter("precoUnitario", SqlDbType.Decimal) { Precision = 10, Scale = 2, Value = model.PrecoUnitario }
            };
            return parametros;
        }

        protected override ItemPedidoViewModel MontaModel(DataRow registro)
        {
            ItemPedidoViewModel i = new ItemPedidoViewModel()
            {
                Id = Convert.ToInt32(registro["id"]),
                PedidoId = Convert.ToInt32(registro["pedidoId"]),
                CardapioId = Convert.ToInt32(registro["cardapioId"]),
                Quantidade = Convert.ToInt32(registro["quantidade"]),
                PrecoUnitario = Convert.ToDecimal(registro["precoUnitario"])
            };
            if (registro.Table.Columns.Contains("nomeItem"))
                i.NomeItem = registro["nomeItem"].ToString();
            return i;
        }

        protected override void SetTabela()
        {
            Tabela = "ItensPedido";
            ChaveIdentity = true;
        }

        public List<ItemPedidoViewModel> ListagemPorPedido(int pedidoId)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("pedidoId", pedidoId)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spItensDoPedido", p);
            List<ItemPedidoViewModel> lista = new List<ItemPedidoViewModel>();
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaModel(registro));
            return lista;
        }
    }
}
