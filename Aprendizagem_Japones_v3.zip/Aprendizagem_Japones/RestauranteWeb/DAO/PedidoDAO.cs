using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RestauranteWeb.Models;

namespace RestauranteWeb.DAO
{
    public class PedidoDAO : PadraoDAO<PedidoViewModel>
    {
        protected override SqlParameter[] CriaParametros(PedidoViewModel model)
        {
            SqlParameter[] parametros =
            {
                new SqlParameter("id", model.Id),
                new SqlParameter("clienteId", model.ClienteId),
                new SqlParameter("funcionarioId", model.FuncionarioId),
                new SqlParameter("dataPedido", SqlDbType.DateTime) { Value = model.DataPedido },
                new SqlParameter("status", model.Status),
                new SqlParameter("observacoes", string.IsNullOrWhiteSpace(model.Observacoes) ? (object)DBNull.Value : model.Observacoes)
            };
            return parametros;
        }

        protected override PedidoViewModel MontaModel(DataRow registro)
        {
            PedidoViewModel p = new PedidoViewModel()
            {
                Id = Convert.ToInt32(registro["id"]),
                ClienteId = Convert.ToInt32(registro["clienteId"]),
                FuncionarioId = Convert.ToInt32(registro["funcionarioId"]),
                DataPedido = Convert.ToDateTime(registro["dataPedido"]),
                Status = Convert.ToInt32(registro["status"]),
                Observacoes = registro["observacoes"] == DBNull.Value ? null : registro["observacoes"].ToString()
            };

            // Colunas que vêm da view vwPedidos
            if (registro.Table.Columns.Contains("nomeCliente"))
            {
                p.NomeCliente = registro["nomeCliente"].ToString();
                p.NomeFuncionario = registro["nomeFuncionario"].ToString();
                p.QtdItens = Convert.ToInt32(registro["qtdItens"]);
                p.ValorTotal = Convert.ToDecimal(registro["valorTotal"]);
            }
            return p;
        }

        protected override void SetTabela()
        {
            Tabela = "Pedidos";
            ChaveIdentity = true;
        }

        /// <summary>Consulta do pedido já com nome do cliente/funcionário e valor total</summary>
        public override PedidoViewModel Consulta(int id)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("id", id)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsultaPedido", p);
            return tabela.Rows.Count == 0 ? null : MontaModel(tabela.Rows[0]);
        }

        /// <summary>Todos os pedidos, do mais recente para o mais antigo</summary>
        public override List<PedidoViewModel> Listagem()
        {
            return ConsultaAvancada(null, null, 0, 0, 0);
        }

        /// <summary>Exclui o pedido e os seus itens (mesma transação, dentro da procedure)</summary>
        public override void Delete(int id)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("id", id)
            };
            HelperDAO.ExecutaProc("spExcluiPedido", p);
        }

        /// <summary>
        /// Consulta com filtros. Datas nulas = sem limite. Para status/cliente/funcionário, 0 = todos.
        /// </summary>
        public List<PedidoViewModel> ConsultaAvancada(DateTime? dataInicial, DateTime? dataFinal,
                                                      int status, int clienteId, int funcionarioId)
        {
            var p = new SqlParameter[]
            {
                HelperDAO.ParametroDataInicial(dataInicial),
                HelperDAO.ParametroDataFinal(dataFinal),
                new SqlParameter("status", status),
                new SqlParameter("clienteId", clienteId),
                new SqlParameter("funcionarioId", funcionarioId)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsultaPedidos", p);
            List<PedidoViewModel> lista = new List<PedidoViewModel>();
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaModel(registro));
            return lista;
        }
    }
}
