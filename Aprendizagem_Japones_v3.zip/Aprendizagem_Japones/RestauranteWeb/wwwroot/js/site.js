// ===================== Utilidades =====================

// Confirma e executa a exclusão de um registro (ex.: apagar('Cliente', 3)).
// O terceiro parâmetro (mensagem) é opcional.
function apagar(controller, id, mensagem) {
    if (confirm(mensagem || 'Confirma a exclusão do registro?'))
        location.href = '/' + controller + '/Delete?id=' + id;
}

function formataMoeda(valor) {
    return 'R$ ' + Number(valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Extrai a mensagem de erro de uma resposta da API ({ mensagem, erros: { campo: msg } })
function mensagemErroApi(xhr) {
    var resp = xhr.responseJSON;
    if (resp && resp.erros) {
        var msgs = [];
        for (var campo in resp.erros)
            msgs.push(resp.erros[campo]);
        return msgs.join(' ');
    }
    if (resp && resp.mensagem)
        return resp.mensagem;
    return 'Não foi possível concluir a operação (erro ' + xhr.status + ').';
}


// ===================== Consulta de pedidos (AJAX + partial views) =====================

// Dados dos filtros. Os nomes devem coincidir com os parâmetros dos métodos do ConsultaController.
function filtrosConsulta() {
    return {
        dataInicial: $('#dataInicial').val(),
        dataFinal: $('#dataFinal').val(),
        status: $('#status').val(),
        clienteId: $('#clienteId').val(),
        funcionarioId: $('#funcionarioId').val()
    };
}

// Faz a chamada AJAX e injeta o HTML devolvido (partial view) na div de destino
function carregaConsulta(url, dados, idDiv) {
    $.ajax({
        url: url,
        data: dados,
        success: function (resposta) {
            if (resposta.erro != undefined)
                alert(resposta.msg);
            else
                document.getElementById(idDiv).innerHTML = resposta;
        },
        error: function () {
            alert('Não foi possível obter os dados da consulta.');
        }
    });
}

function aplicaFiltroConsulta() {
    var f = filtrosConsulta();
    carregaConsulta('/Consulta/ObtemPedidos', f, 'resultadoPedidos');
    carregaConsulta('/Consulta/ObtemItensMaisVendidos', { dataInicial: f.dataInicial, dataFinal: f.dataFinal }, 'resultadoItens');
    carregaConsulta('/Consulta/ObtemFaturamentoFuncionarios', { dataInicial: f.dataInicial, dataFinal: f.dataFinal }, 'resultadoFuncionarios');
}

function limpaFiltroConsulta() {
    $('#dataInicial').val('');
    $('#dataFinal').val('');
    $('#status').val('0');
    $('#clienteId').val('0');
    $('#funcionarioId').val('0');
    aplicaFiltroConsulta();
}


// ===================== Itens do pedido (AJAX chamando a API REST) =====================
// Variáveis pedidoId e itensPermitidos são definidas na tela de edição do pedido.

// Desenha a tabela de itens a partir do pedido devolvido pela API (JSON)
function mostraItensPedido(pedido) {
    var $corpo = $('#gridItensPedido tbody');
    $corpo.empty();

    if (!pedido.itens || pedido.itens.length === 0) {
        $corpo.append($('<tr>').append($('<td colspan="5" class="text-muted">').text('Nenhum item lançado.')));
    }
    else {
        $.each(pedido.itens, function (i, item) {
            var $linha = $('<tr>');
            // .text() evita que nomes com caracteres especiais virem HTML
            $linha.append($('<td>').text(item.nomeItem));
            $linha.append($('<td class="text-right">').text(item.quantidade));
            $linha.append($('<td class="text-right">').text(formataMoeda(item.precoUnitario)));
            $linha.append($('<td class="text-right">').text(formataMoeda(item.subtotal)));

            var $acoes = $('<td class="text-right">');
            if (itensPermitidos) {
                $acoes.append($('<button type="button" class="btn btn-outline-danger btn-sm">').text('Remover')
                    .on('click', function () { removeItemPedido(item.id); }));
            }
            $linha.append($acoes);
            $corpo.append($linha);
        });
    }
    $('#totalPedido').text(formataMoeda(pedido.valorTotal));
}

function carregaItensPedido() {
    $('#msgItens').text('');
    $.ajax({
        url: '/api/pedidos/' + pedidoId,
        method: 'GET',
        success: mostraItensPedido,
        error: function (xhr) { $('#msgItens').text(mensagemErroApi(xhr)); }
    });
}

function adicionaItemPedido() {
    var cardapioId = parseInt($('#cardapioId').val());
    var quantidade = parseInt($('#quantidade').val());
    $('#msgItens').text('');

    $.ajax({
        url: '/api/pedidos/' + pedidoId + '/itens',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ cardapioId: cardapioId || 0, quantidade: quantidade || 0 }),
        success: function (pedido) {
            mostraItensPedido(pedido);
            $('#cardapioId').val('0');
            $('#quantidade').val('1');
        },
        error: function (xhr) { $('#msgItens').text(mensagemErroApi(xhr)); }
    });
}

function removeItemPedido(itemId) {
    if (!confirm('Remover este item do pedido?'))
        return;
    $('#msgItens').text('');

    $.ajax({
        url: '/api/pedidos/' + pedidoId + '/itens/' + itemId,
        method: 'DELETE',
        success: mostraItensPedido,
        error: function (xhr) { $('#msgItens').text(mensagemErroApi(xhr)); }
    });
}
