using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

var builder = WebApplication.CreateBuilder(args);

// A string de conexão fica no appsettings.json
ConexaoBD.StringConexao = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddControllersWithViews();

// ---------- Sessão: controle de acesso e perfil do usuário ----------
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".RestauranteWeb.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.IdleTimeout = TimeSpan.FromMinutes(60);
});

// ---------- Swagger: documentação das APIs ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "API do Restaurante",
        Version = "v1",
        Description = "Clientes, funcionários, cardápio, pedidos (com itens) e consultas de análise dos pedidos."
    });

    // Comentários /// dos controllers aparecem na documentação
    string arquivoXml = Path.Combine(AppContext.BaseDirectory, "RestauranteWeb.xml");
    if (File.Exists(arquivoXml))
        c.IncludeXmlComments(arquivoXml);

    // Documenta só as APIs (as telas MVC não entram no Swagger)
    c.DocInclusionPredicate((docName, apiDesc) =>
        apiDesc.ActionDescriptor.EndpointMetadata.OfType<ApiControllerAttribute>().Any());
});

var app = builder.Build();

// Cultura pt-BR: permite digitar valores como 25,90 nos formulários
var cultura = new CultureInfo("pt-BR");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(cultura),
    SupportedCultures = new List<CultureInfo> { cultura },
    SupportedUICultures = new List<CultureInfo> { cultura }
});

// Erros inesperados nas APIs viram JSON (as telas usam a página de erro normal)
app.UseWhen(contexto => contexto.Request.Path.StartsWithSegments("/api"), api =>
{
    api.UseExceptionHandler(erroApp => erroApp.Run(async contexto =>
    {
        contexto.Response.StatusCode = StatusCodes.Status500InternalServerError;
        await contexto.Response.WriteAsJsonAsync(new ErroApiModel("Erro interno ao processar a requisição."));
    }));
});

if (app.Environment.IsDevelopment())
    app.UseDeveloperExceptionPage();
else
    app.UseExceptionHandler("/Home/Error");

app.UseStaticFiles();

// Deve ficar antes de MapControllerRoute para os controllers acessarem HttpContext.Session
app.UseSession();

app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "API do Restaurante v1"));

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();