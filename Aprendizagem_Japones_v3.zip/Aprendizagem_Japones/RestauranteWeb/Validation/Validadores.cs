using System;
using System.Collections.Generic;
using System.Net.Mail;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Validation
{
    // Regras simples para impedir caracteres incompatíveis com cada tipo de campo.
    internal static class RegrasTexto
    {
        public static bool NomeValido(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            foreach (char caractere in texto)
            {
                // Aceita letras (inclusive acentuadas), espaços, hífen e apóstrofo.
                if (!char.IsLetter(caractere) && caractere != ' ' &&
                    caractere != '-' && caractere != (char)39)
                    return false;
            }
            return true;
        }

        public static bool TelefonePossuiFormatoPermitido(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            foreach (char caractere in texto)
            {
                if (!char.IsDigit(caractere) && caractere != ' ' &&
                    caractere != '(' && caractere != ')' &&
                    caractere != '-' && caractere != (char)39)
                    return false;
            }
            return true;
        }

        public static bool CpfPossuiFormatoPermitido(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            foreach (char caractere in texto)
            {
                if (!char.IsDigit(caractere) && caractere != '.' &&
                    caractere != '-' && caractere != (char)39)
                    return false;
            }
            return true;
        }
    }
    /*
     * As regras de validação ficam aqui para serem usadas tanto pelas telas (MVC)
     * quanto pelas APIs. Cada método devolve um dicionário "campo -> mensagem";
     * dicionário vazio = dados válidos. Os nomes de campo são os das propriedades das Models.
     * Alguns métodos também normalizam os dados (ex.: CPF e telefone ficam só com dígitos).
     */

    public static class ClienteValidador
    {
        public static Dictionary<string, string> Valida(ClienteViewModel m, ClienteDAO dao)
        {
            var erros = new Dictionary<string, string>();

            m.Nome = m.Nome?.Trim();
            m.Email = m.Email?.Trim();

            if (string.IsNullOrWhiteSpace(m.Nome))
                erros["Nome"] = "Preencha o nome.";
            else if (!RegrasTexto.NomeValido(m.Nome))
                erros["Nome"] = "O nome deve conter somente letras. Não utilize números.";
            else if (m.Nome.Length > 100)
                erros["Nome"] = "O nome deve ter no máximo 100 caracteres.";

            if (string.IsNullOrWhiteSpace(m.Cpf))
                erros["Cpf"] = "Preencha o CPF.";
            else if (!RegrasTexto.CpfPossuiFormatoPermitido(m.Cpf) || !Opcoes.CpfValido(m.Cpf))
                erros["Cpf"] = "CPF inválido. Informe somente números ou a pontuação padrão.";
            else
            {
                m.Cpf = Opcoes.SoDigitos(m.Cpf);
                var existente = dao.ConsultaPorCpf(m.Cpf);
                if (existente != null && existente.Id != m.Id)
                    erros["Cpf"] = "Já existe um cliente cadastrado com este CPF.";
            }

            string telefone = Opcoes.SoDigitos(m.Telefone);
            if (string.IsNullOrWhiteSpace(m.Telefone))
                erros["Telefone"] = "Preencha o telefone.";
            else if (!RegrasTexto.TelefonePossuiFormatoPermitido(m.Telefone))
                erros["Telefone"] = "O telefone deve conter somente números e caracteres de formatação.";
            else if (telefone.Length != 10 && telefone.Length != 11)
                erros["Telefone"] = "Informe o telefone com DDD (10 ou 11 dígitos).";
            else
                m.Telefone = telefone;

            // E-mail é opcional, mas se for informado precisa ser válido
            if (!string.IsNullOrEmpty(m.Email))
            {
                if (m.Email.Length > 100)
                    erros["Email"] = "O e-mail deve ter no máximo 100 caracteres.";
                else if (!EmailValido(m.Email))
                    erros["Email"] = "Informe um e-mail válido.";
            }

            return erros;
        }

        private static bool EmailValido(string email)
        {
            try
            {
                return new MailAddress(email).Address == email;
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }

    public static class FuncionarioValidador
    {
        public static Dictionary<string, string> Valida(FuncionarioViewModel m)
        {
            var erros = new Dictionary<string, string>();

            m.Nome = m.Nome?.Trim();
            m.Cargo = m.Cargo?.Trim();

            if (string.IsNullOrWhiteSpace(m.Nome))
                erros["Nome"] = "Preencha o nome.";
            else if (!RegrasTexto.NomeValido(m.Nome))
                erros["Nome"] = "O nome deve conter somente letras, não utilize números.";
            else if (m.Nome.Length > 100)
                erros["Nome"] = "O nome deve ter no máximo 100 caracteres.";

            if (string.IsNullOrWhiteSpace(m.Cargo))
                erros["Cargo"] = "Preencha o cargo.";
            else if (!RegrasTexto.NomeValido(m.Cargo))
                erros["Cargo"] = "O cargo deve conter somente letras, não utilize numeros";
            else if (m.Cargo.Length > 50)
                erros["Cargo"] = "O cargo deve ter no máximo 50 caracteres.";

            string telefone = Opcoes.SoDigitos(m.Telefone);
            if (string.IsNullOrWhiteSpace(m.Telefone))
                erros["Telefone"] = "Preencha o telefone.";
            else if (!RegrasTexto.TelefonePossuiFormatoPermitido(m.Telefone))
                erros["Telefone"] = "O telefone deve conter somente números e caracteres de formatação.";
            else if (telefone.Length != 10 && telefone.Length != 11)
                erros["Telefone"] = "Informe o telefone com DDD (10 ou 11 dígitos).";
            else
                m.Telefone = telefone;

            if (m.DataAdmissao == default(DateTime))
                erros["DataAdmissao"] = "Informe a data de admissão.";
            else if (m.DataAdmissao.Year < 1950)
                erros["DataAdmissao"] = "A data de admissão é muito antiga.";
            else if (m.DataAdmissao.Date > DateTime.Today)
                erros["DataAdmissao"] = "A data de admissão não pode ser futura.";
            else
                m.DataAdmissao = m.DataAdmissao.Date;

            return erros;
        }
    }

    public static class CardapioValidador
    {
        public static Dictionary<string, string> Valida(ItemCardapioViewModel m)
        {
            var erros = new Dictionary<string, string>();

            m.Nome = m.Nome?.Trim();
            m.Descricao = m.Descricao?.Trim();

            if (string.IsNullOrWhiteSpace(m.Nome))
                erros["Nome"] = "Preencha o nome do item.";
            else if (m.Nome.Length > 100)
                erros["Nome"] = "O nome deve ter no máximo 100 caracteres.";

            // Descrição é opcional
            if (!string.IsNullOrEmpty(m.Descricao) && m.Descricao.Length > 300)
                erros["Descricao"] = "A descrição deve ter no máximo 300 caracteres.";

            if (!Opcoes.CategoriasCardapio.ContainsKey(m.Categoria))
                erros["Categoria"] = "Selecione a categoria.";

            if (m.Preco <= 0)
                erros["Preco"] = "Informe um preço maior que zero (ex.: 25,90).";
            else if (Math.Round(m.Preco, 2) != m.Preco)
                erros["Preco"] = "Use no máximo 2 casas decimais.";
            else if (m.Preco >= 10000)
                erros["Preco"] = "Preço inválido.";

            return erros;
        }
    }

    public static class PedidoValidador
    {
        /// <summary>Valida os dados do cabeçalho do pedido (os itens têm validador próprio)</summary>
        public static Dictionary<string, string> Valida(PedidoViewModel m)
        {
            var erros = new Dictionary<string, string>();

            if (m.ClienteId <= 0 || new ClienteDAO().Consulta(m.ClienteId) == null)
                erros["ClienteId"] = "Selecione um cliente válido.";

            if (m.FuncionarioId <= 0 || new FuncionarioDAO().Consulta(m.FuncionarioId) == null)
                erros["FuncionarioId"] = "Selecione um funcionário válido.";

            if (m.DataPedido == default(DateTime))
                erros["DataPedido"] = "Informe a data do pedido.";
            else if (m.DataPedido.Year < 2000)
                erros["DataPedido"] = "A data do pedido é muito antiga.";
            else if (m.DataPedido.Date > DateTime.Today)
                erros["DataPedido"] = "A data do pedido não pode ser futura.";

            if (!Opcoes.StatusPedido.ContainsKey(m.Status))
                erros["Status"] = "Selecione o status do pedido.";

            m.Observacoes = m.Observacoes?.Trim();
            if (!string.IsNullOrEmpty(m.Observacoes) && m.Observacoes.Length > 300)
                erros["Observacoes"] = "As observações devem ter no máximo 300 caracteres.";

            return erros;
        }
    }

    public static class ItemPedidoValidador
    {
        /// <summary>
        /// Valida a inclusão de um item em um pedido que está com o status informado.
        /// </summary>
        public static Dictionary<string, string> Valida(int cardapioId, int quantidade, int statusDoPedido)
        {
            var erros = new Dictionary<string, string>();

            if (!Opcoes.PedidoPermiteAlterarItens(statusDoPedido))
                erros["Pedido"] = "Só é possível alterar os itens de pedidos Abertos ou Em preparo.";

            var item = cardapioId > 0 ? new CardapioDAO().Consulta(cardapioId) : null;
            if (item == null)
                erros["CardapioId"] = "Selecione um item do cardápio.";
            else if (!item.Ativo)
                erros["CardapioId"] = "Este item não está disponível no cardápio.";

            if (quantidade < 1 || quantidade > 99)
                erros["Quantidade"] = "A quantidade deve ser entre 1 e 99.";

            return erros;
        }
    }
}
