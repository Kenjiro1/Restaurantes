using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RestauranteWeb.Views.Home
{
    public class HomeClienteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
