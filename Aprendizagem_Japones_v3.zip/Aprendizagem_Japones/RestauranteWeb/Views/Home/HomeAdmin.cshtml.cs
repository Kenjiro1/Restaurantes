using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RestauranteWeb.Views.Home
{
    public class HomeAdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
