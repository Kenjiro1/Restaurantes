using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RestauranteWeb.Views.Carrinho
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
