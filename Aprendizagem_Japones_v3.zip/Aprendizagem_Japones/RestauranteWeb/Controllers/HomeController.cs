using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            try
            {
                bool logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
                string perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);

                ViewBag.Logado = logado;
                ViewBag.Perfil = perfil;

                if (!logado)
                    return View();

                if (string.Equals(perfil, "Admin", StringComparison.OrdinalIgnoreCase))
                    return RedirectToAction("HomeAdmin");

                if (string.Equals(perfil, "Cliente", StringComparison.OrdinalIgnoreCase))
                    return RedirectToAction("HomeCliente");

                return View();
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public IActionResult HomeAdmin()
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (!HelperControllers.EhAdmin(HttpContext.Session))
                    return RedirectToAction("HomeCliente");

                ViewBag.Logado = true;
                ViewBag.Perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);
                ViewBag.UsuarioLogin = HttpContext.Session.GetString("UsuarioLogin") ?? "Admin";

                return View();
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public IActionResult HomeCliente()
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (HelperControllers.EhAdmin(HttpContext.Session))
                    return RedirectToAction("HomeAdmin");

                ViewBag.Logado = true;
                ViewBag.Perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);
                ViewBag.UsuarioLogin = HttpContext.Session.GetString("UsuarioLogin") ?? "Cliente";

                return View();
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
    }
}