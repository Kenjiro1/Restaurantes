using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers
{
    /// <summary>
    /// Tela de consultas de análise dos pedidos. A tela chama, via AJAX, os métodos Obtem...,
    /// que devolvem partial views (HTML) para serem "injetadas" na página (como na seção 36 da apostila).
    /// </summary>
    public class ConsultaController : Controller
    {
        private IActionResult? VerificaAcessoAdmin()
        {
            if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                return RedirectToAction("Index", "Login");

            if (!HelperControllers.EhAdmin(HttpContext.Session))
                return RedirectToAction("Index", "Home");

            ViewBag.Logado = true;
            ViewBag.Perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);
            return null;
        }

        public IActionResult Index()
        {
            try
            {
                var bloqueio = VerificaAcessoAdmin();
                if (bloqueio != null)
                    return bloqueio;

                ViewBag.Clientes = new ClienteDAO().Listagem();
                ViewBag.Funcionarios = new FuncionarioDAO().Listagem();
                return View();
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public IActionResult ObtemPedidos(DateTime? dataInicial, DateTime? dataFinal,
                                          int status, int clienteId, int funcionarioId)
        {
            try
            {
                var bloqueio = VerificaAcessoAdmin();
                if (bloqueio != null)
                    return bloqueio;

                var lista = new PedidoDAO().ConsultaAvancada(dataInicial, dataFinal, status, clienteId, funcionarioId);
                return PartialView("pvGridPedidos", ConsultaPedidosResultado.De(lista));
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }

        public IActionResult ObtemItensMaisVendidos(DateTime? dataInicial, DateTime? dataFinal)
        {
            try
            {
                var bloqueio = VerificaAcessoAdmin();
                if (bloqueio != null)
                    return bloqueio;

                var lista = new ConsultaDAO().ItensMaisVendidos(dataInicial, dataFinal, 10);
                return PartialView("pvGridItensMaisVendidos", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }

        public IActionResult ObtemFaturamentoFuncionarios(DateTime? dataInicial, DateTime? dataFinal)
        {
            try
            {
                var bloqueio = VerificaAcessoAdmin();
                if (bloqueio != null)
                    return bloqueio;

                var lista = new ConsultaDAO().FaturamentoPorFuncionario(dataInicial, dataFinal);
                return PartialView("pvGridFaturamentoFuncionarios", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
    }
}