﻿using Microsoft.AspNetCore.Http;

namespace RestauranteWeb.Controllers
{
    public static class HelperControllers
    {
        public static bool VerificaUserLogado(ISession session)
        {
            return session.GetString("Logado") == "true";
        }

        public static string ObtemPerfilUsuario(ISession session)
        {
            return session.GetString("Perfil") ?? string.Empty;
        }

        public static bool EhAdmin(ISession session)
        {
            return VerificaUserLogado(session) &&
                   string.Equals(ObtemPerfilUsuario(session), "Admin", StringComparison.OrdinalIgnoreCase);
        }

        public static bool EhCliente(ISession session)
        {
            return VerificaUserLogado(session) &&
                   string.Equals(ObtemPerfilUsuario(session), "Cliente", StringComparison.OrdinalIgnoreCase);
        }
    }
}