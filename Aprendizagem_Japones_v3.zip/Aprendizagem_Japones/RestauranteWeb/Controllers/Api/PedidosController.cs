using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;
using RestauranteWeb.Validation;

namespace RestauranteWeb.Controllers.Api
{
    /// <summary>
    /// Pedidos do restaurante e seus itens.
    /// Status: 1 = Aberto, 2 = Em preparo, 3 = Entregue, 4 = Cancelado.
    /// </summary>
    [ApiController]
    [Route("api/pedidos")]
    [Produces("application/json")]
    public class PedidosController : ControllerBase
    {
        private readonly PedidoDAO _pedidos = new PedidoDAO();
        private readonly ItemPedidoDAO _itens = new ItemPedidoDAO();

        /// <summary>Devolve o pedido já com a lista de itens</summary>
        private PedidoViewModel PedidoCompleto(int id)
        {
            PedidoViewModel pedido = _pedidos.Consulta(id);
            if (pedido != null)
                pedido.Itens = _itens.ListagemPorPedido(id);
            return pedido;
        }

        /// <summary>Lista pedidos (do mais recente para o mais antigo), com filtros opcionais</summary>
        /// <param name="dataInicial">Pedidos a partir desta data</param>
        /// <param name="dataFinal">Pedidos até esta data (o dia inteiro é considerado)</param>
        /// <param name="status">1 Aberto, 2 Em preparo, 3 Entregue, 4 Cancelado (0 ou vazio = todos)</param>
        /// <param name="clienteId">Código do cliente (0 ou vazio = todos)</param>
        /// <param name="funcionarioId">Código do funcionário (0 ou vazio = todos)</param>
        [HttpGet]
        public ActionResult<List<PedidoViewModel>> Listar([FromQuery] DateTime? dataInicial, [FromQuery] DateTime? dataFinal,
                                                          [FromQuery] int status = 0, [FromQuery] int clienteId = 0,
                                                          [FromQuery] int funcionarioId = 0)
        {
            return _pedidos.ConsultaAvancada(dataInicial, dataFinal, status, clienteId, funcionarioId);
        }

        /// <summary>Obtém um pedido com os seus itens</summary>
        /// <param name="id">Número do pedido</param>
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public ActionResult<PedidoViewModel> Obter(int id)
        {
            PedidoViewModel pedido = PedidoCompleto(id);
            if (pedido == null)
                return NotFound(new ErroApiModel("Pedido não encontrado."));
            return pedido;
        }

        /// <summary>
        /// Cria um pedido. Os itens (cardapioId + quantidade) podem ser enviados junto.
        /// Se dataPedido não for enviada, usa a data/hora atual; se status não for enviado, usa 1 (Aberto).
        /// </summary>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        public ActionResult<PedidoViewModel> Incluir([FromBody] PedidoViewModel model)
        {
            if (model == null)
                return BadRequest(new ErroApiModel("Corpo da requisição inválido."));

            model.Id = 0;
            if (model.DataPedido == default(DateTime))
                model.DataPedido = DateTime.Now;
            if (model.Status == 0)
                model.Status = Opcoes.StatusAberto;

            var erros = PedidoValidador.Valida(model);

            var itens = model.Itens ?? new List<ItemPedidoViewModel>();
            for (int i = 0; i < itens.Count; i++)
            {
                foreach (var erro in ItemPedidoValidador.Valida(itens[i].CardapioId, itens[i].Quantidade, model.Status))
                    erros["Itens[" + i + "]." + erro.Key] = erro.Value;
            }

            if (erros.Count > 0)
                return BadRequest(new ErroApiModel("Dados inválidos.", erros));

            model.Id = _pedidos.Insert(model);
            foreach (var item in itens)
            {
                item.Id = 0;
                item.PedidoId = model.Id;
                _itens.Insert(item);
            }

            return CreatedAtAction(nameof(Obter), new { id = model.Id }, PedidoCompleto(model.Id));
        }

        /// <summary>Altera os dados do pedido (cliente, funcionário, data, status, observações). Os itens têm rotas próprias.</summary>
        /// <param name="id">Número do pedido</param>
        /// <param name="model">Novos dados do pedido</param>
        [HttpPut("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public IActionResult Alterar(int id, [FromBody] PedidoViewModel model)
        {
            if (model == null)
                return BadRequest(new ErroApiModel("Corpo da requisição inválido."));

            if (_pedidos.Consulta(id) == null)
                return NotFound(new ErroApiModel("Pedido não encontrado."));

            model.Id = id;
            var erros = PedidoValidador.Valida(model);
            if (erros.Count > 0)
                return BadRequest(new ErroApiModel("Dados inválidos.", erros));

            _pedidos.Update(model);
            return NoContent();
        }

        /// <summary>Altera somente o status do pedido (1 Aberto, 2 Em preparo, 3 Entregue, 4 Cancelado)</summary>
        /// <param name="id">Número do pedido</param>
        /// <param name="requisicao">Novo status</param>
        [HttpPut("{id:int}/status")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public IActionResult AlterarStatus(int id, [FromBody] AlteraStatusRequest requisicao)
        {
            PedidoViewModel pedido = _pedidos.Consulta(id);
            if (pedido == null)
                return NotFound(new ErroApiModel("Pedido não encontrado."));

            if (requisicao == null || !Opcoes.StatusPedido.ContainsKey(requisicao.Status))
                return BadRequest(new ErroApiModel("Dados inválidos.",
                    new Dictionary<string, string> { { "Status", "Status inválido. Use 1, 2, 3 ou 4." } }));

            pedido.Status = requisicao.Status;
            _pedidos.Update(pedido);
            return NoContent();
        }

        /// <summary>Exclui o pedido e todos os seus itens</summary>
        /// <param name="id">Número do pedido</param>
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public IActionResult Excluir(int id)
        {
            if (_pedidos.Consulta(id) == null)
                return NotFound(new ErroApiModel("Pedido não encontrado."));

            _pedidos.Delete(id);
            return NoContent();
        }

        /// <summary>
        /// Adiciona um item ao pedido (se o item já estiver no pedido, soma a quantidade).
        /// O preço é o do cardápio no momento. Só é permitido em pedidos Abertos ou Em preparo.
        /// Devolve o pedido atualizado.
        /// </summary>
        /// <param name="id">Número do pedido</param>
        /// <param name="item">cardapioId e quantidade (os demais campos são ignorados)</param>
        [HttpPost("{id:int}/itens")]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public ActionResult<PedidoViewModel> IncluirItem(int id, [FromBody] ItemPedidoViewModel item)
        {
            if (item == null)
                return BadRequest(new ErroApiModel("Corpo da requisição inválido."));

            PedidoViewModel pedido = _pedidos.Consulta(id);
            if (pedido == null)
                return NotFound(new ErroApiModel("Pedido não encontrado."));

            var erros = ItemPedidoValidador.Valida(item.CardapioId, item.Quantidade, pedido.Status);
            if (erros.Count > 0)
                return BadRequest(new ErroApiModel("Dados inválidos.", erros));

            item.Id = 0;
            item.PedidoId = id;
            _itens.Insert(item);

            return PedidoCompleto(id);
        }

        /// <summary>Remove um item do pedido (só em pedidos Abertos ou Em preparo). Devolve o pedido atualizado.</summary>
        /// <param name="id">Número do pedido</param>
        /// <param name="itemId">Código do item dentro do pedido (campo "id" da lista de itens)</param>
        [HttpDelete("{id:int}/itens/{itemId:int}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public ActionResult<PedidoViewModel> ExcluirItem(int id, int itemId)
        {
            PedidoViewModel pedido = _pedidos.Consulta(id);
            if (pedido == null)
                return NotFound(new ErroApiModel("Pedido não encontrado."));

            ItemPedidoViewModel item = _itens.Consulta(itemId);
            if (item == null || item.PedidoId != id)
                return NotFound(new ErroApiModel("Item não encontrado neste pedido."));

            if (!Opcoes.PedidoPermiteAlterarItens(pedido.Status))
                return BadRequest(new ErroApiModel("Só é possível alterar os itens de pedidos Abertos ou Em preparo."));

            _itens.Delete(itemId);

            return PedidoCompleto(id);
        }
    }
}
