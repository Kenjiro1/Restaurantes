using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers.Api
{
    /// <summary>
    /// Consultas para analisar os pedidos realizados.
    /// Em todas, as datas são opcionais; quando informadas, o dia inicial e o dia final entram na consulta.
    /// </summary>
    [ApiController]
    [Route("api/consultas")]
    [Produces("application/json")]
    public class ConsultasController : ControllerBase
    {
        /// <summary>Pedidos com filtros, mais a quantidade de pedidos e o valor total (sem contar os cancelados)</summary>
        /// <param name="dataInicial">Pedidos a partir desta data</param>
        /// <param name="dataFinal">Pedidos até esta data</param>
        /// <param name="status">1 Aberto, 2 Em preparo, 3 Entregue, 4 Cancelado (0 ou vazio = todos)</param>
        /// <param name="clienteId">Código do cliente (0 ou vazio = todos)</param>
        /// <param name="funcionarioId">Código do funcionário (0 ou vazio = todos)</param>
        [HttpGet("pedidos")]
        public ActionResult<ConsultaPedidosResultado> Pedidos([FromQuery] DateTime? dataInicial, [FromQuery] DateTime? dataFinal,
                                                              [FromQuery] int status = 0, [FromQuery] int clienteId = 0,
                                                              [FromQuery] int funcionarioId = 0)
        {
            var lista = new PedidoDAO().ConsultaAvancada(dataInicial, dataFinal, status, clienteId, funcionarioId);
            return ConsultaPedidosResultado.De(lista);
        }

        /// <summary>Itens do cardápio mais vendidos (quantidade e faturamento), sem contar pedidos cancelados</summary>
        /// <param name="dataInicial">A partir desta data</param>
        /// <param name="dataFinal">Até esta data</param>
        /// <param name="top">Quantos itens retornar (padrão 10)</param>
        [HttpGet("itens-mais-vendidos")]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        public ActionResult<List<ItemMaisVendidoViewModel>> ItensMaisVendidos([FromQuery] DateTime? dataInicial,
                                                                              [FromQuery] DateTime? dataFinal,
                                                                              [FromQuery] int top = 10)
        {
            if (top < 1 || top > 100)
                return BadRequest(new ErroApiModel("O parâmetro top deve estar entre 1 e 100."));

            return new ConsultaDAO().ItensMaisVendidos(dataInicial, dataFinal, top);
        }

        /// <summary>Quantidade de pedidos e faturamento por funcionário, sem contar pedidos cancelados</summary>
        /// <param name="dataInicial">A partir desta data</param>
        /// <param name="dataFinal">Até esta data</param>
        [HttpGet("faturamento-por-funcionario")]
        public ActionResult<List<FaturamentoFuncionarioViewModel>> FaturamentoPorFuncionario([FromQuery] DateTime? dataInicial,
                                                                                             [FromQuery] DateTime? dataFinal)
        {
            return new ConsultaDAO().FaturamentoPorFuncionario(dataInicial, dataFinal);
        }
    }
}
