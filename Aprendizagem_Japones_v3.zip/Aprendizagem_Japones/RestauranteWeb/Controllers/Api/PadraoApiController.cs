using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers.Api
{
    /// <summary>
    /// API REST padrão (GET lista, GET por id, POST, PUT, DELETE) para os cadastros simples.
    /// Os controllers filhos informam a DAO, a rota e as regras de validação.
    /// </summary>
    [ApiController]
    [Produces("application/json")]
    public abstract class PadraoApiController<T> : ControllerBase where T : PadraoViewModel
    {
        protected PadraoDAO<T> DAO { get; set; }

        /// <summary>Devolve os erros de validação (campo -> mensagem). Vazio = dados válidos.</summary>
        protected abstract Dictionary<string, string> Valida(T model);

        /// <summary>Mensagem quando o registro não pode ser excluído por ter dependentes; null = pode excluir.</summary>
        protected virtual string MotivoBloqueioExclusao(int id)
        {
            return null;
        }

        /// <summary>Lista todos os registros</summary>
        [HttpGet]
        public virtual ActionResult<List<T>> Listar()
        {
            return DAO.Listagem();
        }

        /// <summary>Obtém um registro pelo id</summary>
        /// <param name="id">Código do registro</param>
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public virtual ActionResult<T> Obter(int id)
        {
            T model = DAO.Consulta(id);
            if (model == null)
                return NotFound(new ErroApiModel("Registro não encontrado."));
            return model;
        }

        /// <summary>Inclui um novo registro (o id é gerado pelo banco)</summary>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        public virtual ActionResult<T> Incluir([FromBody] T model)
        {
            if (model == null)
                return BadRequest(new ErroApiModel("Corpo da requisição inválido."));

            model.Id = 0;
            var erros = Valida(model);
            if (erros.Count > 0)
                return BadRequest(new ErroApiModel("Dados inválidos.", erros));

            model.Id = DAO.Insert(model);
            return CreatedAtAction(nameof(Obter), new { id = model.Id }, DAO.Consulta(model.Id));
        }

        /// <summary>Altera um registro existente</summary>
        /// <param name="id">Código do registro</param>
        /// <param name="model">Novos dados (o id da URL é o que vale)</param>
        [HttpPut("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErroApiModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        public virtual IActionResult Alterar(int id, [FromBody] T model)
        {
            if (model == null)
                return BadRequest(new ErroApiModel("Corpo da requisição inválido."));

            if (DAO.Consulta(id) == null)
                return NotFound(new ErroApiModel("Registro não encontrado."));

            model.Id = id;
            var erros = Valida(model);
            if (erros.Count > 0)
                return BadRequest(new ErroApiModel("Dados inválidos.", erros));

            DAO.Update(model);
            return NoContent();
        }

        /// <summary>Exclui um registro</summary>
        /// <param name="id">Código do registro</param>
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErroApiModel))]
        [ProducesResponseType(StatusCodes.Status409Conflict, Type = typeof(ErroApiModel))]
        public virtual IActionResult Excluir(int id)
        {
            if (DAO.Consulta(id) == null)
                return NotFound(new ErroApiModel("Registro não encontrado."));

            string motivo = MotivoBloqueioExclusao(id);
            if (motivo != null)
                return Conflict(new ErroApiModel(motivo));

            DAO.Delete(id);
            return NoContent();
        }
    }
}
