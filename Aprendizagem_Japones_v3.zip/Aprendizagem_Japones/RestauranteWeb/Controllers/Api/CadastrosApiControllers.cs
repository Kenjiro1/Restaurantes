using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;
using RestauranteWeb.Validation;

namespace RestauranteWeb.Controllers.Api
{
    /// <summary>Clientes do restaurante</summary>
    [ApiController]
    [Route("api/clientes")]
    public class ClientesController : PadraoApiController<ClienteViewModel>
    {
        public ClientesController()
        {
            DAO = new ClienteDAO();
        }

        protected override Dictionary<string, string> Valida(ClienteViewModel model)
        {
            return ClienteValidador.Valida(model, (ClienteDAO)DAO);
        }

        protected override string MotivoBloqueioExclusao(int id)
        {
            return ((ClienteDAO)DAO).EmUso(id) ? "Não é possível excluir o cliente, pois ele possui pedidos." : null;
        }
    }

    /// <summary>Funcionários do restaurante</summary>
    [ApiController]
    [Route("api/funcionarios")]
    public class FuncionariosController : PadraoApiController<FuncionarioViewModel>
    {
        public FuncionariosController()
        {
            DAO = new FuncionarioDAO();
        }

        protected override Dictionary<string, string> Valida(FuncionarioViewModel model)
        {
            return FuncionarioValidador.Valida(model);
        }

        protected override string MotivoBloqueioExclusao(int id)
        {
            return ((FuncionarioDAO)DAO).EmUso(id) ? "Não é possível excluir o funcionário, pois ele possui pedidos atendidos." : null;
        }
    }

    /// <summary>Itens do cardápio</summary>
    [ApiController]
    [Route("api/cardapio")]
    public class ItensCardapioController : PadraoApiController<ItemCardapioViewModel>
    {
        public ItensCardapioController()
        {
            DAO = new CardapioDAO();
        }

        protected override Dictionary<string, string> Valida(ItemCardapioViewModel model)
        {
            return CardapioValidador.Valida(model);
        }

        protected override string MotivoBloqueioExclusao(int id)
        {
            return ((CardapioDAO)DAO).EmUso(id)
                ? "O item já foi usado em pedidos e não pode ser excluído. Altere-o para indisponível (ativo = false)."
                : null;
        }

        /// <summary>Lista somente os itens disponíveis (ativos) para novos pedidos</summary>
        [HttpGet("ativos")]
        public ActionResult<List<ItemCardapioViewModel>> ListarAtivos()
        {
            return ((CardapioDAO)DAO).ListagemAtivos();
        }
    }
}
