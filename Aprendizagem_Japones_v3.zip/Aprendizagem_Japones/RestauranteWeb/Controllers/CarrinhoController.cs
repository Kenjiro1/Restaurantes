﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers
{
    public class CarrinhoController : Controller
    {
        public IActionResult Index()
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (!HelperControllers.EhCliente(HttpContext.Session))
                    return RedirectToAction("HomeAdmin", "Home");

                ViewBag.Logado = true;
                ViewBag.Perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);

                var itens = CarrinhoHelper.ObterCarrinho(HttpContext.Session);
                ViewBag.Total = itens.Sum(i => i.Subtotal);
                return View(itens);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        [HttpPost]
        public IActionResult Adicionar(int id, int quantidade = 1)
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (!HelperControllers.EhCliente(HttpContext.Session))
                    return RedirectToAction("HomeAdmin", "Home");

                CardapioDAO pratoDao = new CardapioDAO();
                var prato = pratoDao.Consulta(id);

                if (prato != null && quantidade > 0)
                {
                    CarrinhoHelper.AdicionarItem(HttpContext.Session, new ItemCarrinhoViewModel
                    {
                        PratoId = prato.Id,
                        NomePrato = prato.Nome,
                        PrecoUnitario = prato.Preco,
                        Quantidade = quantidade
                    });
                }

                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        [HttpPost]
        public IActionResult Remover(int pratoId)
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (!HelperControllers.EhCliente(HttpContext.Session))
                    return RedirectToAction("HomeAdmin", "Home");

                CarrinhoHelper.RemoverItem(HttpContext.Session, pratoId);
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public IActionResult ConfirmarPedido()
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (!HelperControllers.EhCliente(HttpContext.Session))
                    return RedirectToAction("HomeAdmin", "Home");

                ViewBag.Logado = true;
                ViewBag.Perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);

                var itens = CarrinhoHelper.ObterCarrinho(HttpContext.Session);
                if (itens == null || !itens.Any())
                    return RedirectToAction("Index"); // Sem itens -> vai para o carrinho

                ViewBag.Total = itens.Sum(i => i.Subtotal);
                return View(itens);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        [HttpPost]
        public IActionResult FinalizarPedido(string? observacoes)
        {
            try
            {
                if (!HelperControllers.VerificaUserLogado(HttpContext.Session))
                    return RedirectToAction("Index", "Login");

                if (!HelperControllers.EhCliente(HttpContext.Session))
                    return RedirectToAction("HomeAdmin", "Home");

                var itens = CarrinhoHelper.ObterCarrinho(HttpContext.Session);
                if (itens == null || !itens.Any())
                    return RedirectToAction("Index");

                var clientes = new ClienteDAO().Listagem();
                var funcionarios = new FuncionarioDAO().Listagem();

                if (!clientes.Any() || !funcionarios.Any())
                    return View("Error", new ErrorViewModel("Cadastre ao menos um cliente e um funcionário antes de gerar pedidos."));

                string usuarioLogin = HttpContext.Session.GetString("UsuarioLogin") ?? string.Empty;
                var clienteMatch = clientes.FirstOrDefault(c =>
                    (!string.IsNullOrWhiteSpace(c.Email) && c.Email.Equals(usuarioLogin, StringComparison.OrdinalIgnoreCase)) ||
                    c.Nome.Contains(usuarioLogin, StringComparison.OrdinalIgnoreCase));

                int clienteId = clienteMatch?.Id ?? clientes.First().Id;
                int funcionarioId = funcionarios.First().Id;

                var pedido = new PedidoViewModel
                {
                    ClienteId = clienteId,
                    FuncionarioId = funcionarioId,
                    DataPedido = DateTime.Now,
                    Status = Opcoes.StatusAberto,
                    Observacoes = string.IsNullOrWhiteSpace(observacoes) ? "Pedido via carrinho" : observacoes.Trim()
                };

                var pedidoDao = new PedidoDAO();
                var itemPedidoDao = new ItemPedidoDAO();

                int novoPedidoId = pedidoDao.Insert(pedido);
                if (novoPedidoId <= 0)
                {
                    // Caso PadraoDAO.Insert não retorne o id em tabelas com identity, busca o último pedido desse cliente
                    var recentes = pedidoDao.ConsultaAvancada(DateTime.Today, DateTime.Now.AddDays(1), 0, clienteId, funcionarioId);
                    novoPedidoId = recentes.FirstOrDefault()?.Id ?? 0;
                }

                if (novoPedidoId > 0)
                {
                    foreach (var item in itens)
                    {
                        itemPedidoDao.Insert(new ItemPedidoViewModel
                        {
                            PedidoId = novoPedidoId,
                            CardapioId = item.PratoId,
                            Quantidade = item.Quantidade,
                            PrecoUnitario = item.PrecoUnitario
                        });
                    }
                }

                CarrinhoHelper.LimparCarrinho(HttpContext.Session);
                TempData["MensagemSucesso"] = $"Pedido #{novoPedidoId} realizado com sucesso!";
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
    }
}