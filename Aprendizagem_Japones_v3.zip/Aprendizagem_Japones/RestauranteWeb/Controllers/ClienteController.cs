using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;
using RestauranteWeb.Validation;

namespace RestauranteWeb.Controllers
{
    public class ClienteController : PadraoController<ClienteViewModel>
    {
        public ClienteController()
        {
            DAO = new ClienteDAO();
            ExigeAdmin = true;
        }

        protected override void ValidaDados(ClienteViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);
            AdicionaErros(ClienteValidador.Valida(model, (ClienteDAO)DAO));
        }

        public override IActionResult Delete(int id)
        {
            try
            {
                if (((ClienteDAO)DAO).EmUso(id))
                    return View("Error", new ErrorViewModel("Não é possível excluir este cliente, pois ele possui pedidos."));
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
            return base.Delete(id);
        }
    }
}