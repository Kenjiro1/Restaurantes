using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;
using RestauranteWeb.Validation;

namespace RestauranteWeb.Controllers
{
    /// <summary>
    /// Tela do pedido: o formulário grava o cabeçalho; os itens são adicionados/removidos
    /// via AJAX (chamando a API /api/pedidos/{id}/itens) na tela de edição.
    /// </summary>
    public class PedidoController : PadraoController<PedidoViewModel>
    {
        public PedidoController()
        {
            DAO = new PedidoDAO();
            ExigeAdmin = true;
        }

        protected override void PreencheDadosParaView(string operacao, PedidoViewModel model)
        {
            ViewBag.Clientes = new ClienteDAO().Listagem();
            ViewBag.Funcionarios = new FuncionarioDAO().Listagem();

            if (operacao == "I")
            {
                if (model.DataPedido == default(DateTime))
                    model.DataPedido = DateTime.Now;
                if (model.Status == 0)
                    model.Status = Opcoes.StatusAberto;
            }
            else
            {
                // Na edição o formulário mostra o total e permite mexer nos itens
                ViewBag.ItensPermitidos = Opcoes.PedidoPermiteAlterarItens(model.Status);
                ViewBag.ItensCardapio = new CardapioDAO().ListagemAtivos();
            }
        }

        protected override void ValidaDados(PedidoViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);
            AdicionaErros(PedidoValidador.Valida(model));
        }

        /// <summary>Depois de criar o pedido, vai direto para a edição para lançar os itens</summary>
        protected override IActionResult RedirecionaAposSalvar(PedidoViewModel model, string operacao)
        {
            if (operacao == "I")
                return RedirectToAction("Edit", new { id = model.Id });
            return RedirectToAction("Index");
        }
    }
}