-- 1. Cria��o da tabela Usuarios
CREATE TABLE Usuarios (
    Id INT NOT NULL PRIMARY KEY,
    Login VARCHAR(50) NOT NULL,
    Senha VARCHAR(100) NOT NULL,
    Perfil VARCHAR(20) NOT NULL -- Ex.: 'Admin' ou 'Cliente'
);
GO

-- 2. Stored Procedure de autentica��o (parametrizada)
CREATE PROCEDURE spAutenticaUsuario
    @login VARCHAR(50),
    @senha VARCHAR(100)
AS
BEGIN
    SELECT Id, Login, Senha, Perfil
    FROM Usuarios
    WHERE Login = @login AND Senha = @senha;
END
GO

-- 3. Stored Procedures compat�veis com PadraoDAO<UsuarioViewModel>
CREATE PROCEDURE spInsert_Usuarios
    @id INT,
    @login VARCHAR(50),
    @senha VARCHAR(100),
    @perfil VARCHAR(20)
AS
BEGIN
    INSERT INTO Usuarios (Id, Login, Senha, Perfil)
    VALUES (@id, @login, @senha, @perfil);
END
GO

CREATE PROCEDURE spUpdate_Usuarios
    @id INT,
    @login VARCHAR(50),
    @senha VARCHAR(100),
    @perfil VARCHAR(20)
AS
BEGIN
    UPDATE Usuarios
    SET Login = @login,
        Senha = @senha,
        Perfil = @perfil
    WHERE Id = @id;
END
GO

-- 4. Registros iniciais de exemplo para teste
INSERT INTO Usuarios (Id, Login, Senha, Perfil) VALUES (1, 'admin', '1234', 'Admin');
INSERT INTO Usuarios (Id, Login, Senha, Perfil) VALUES (2, 'cliente', '1234', 'Cliente');
GO


IF OBJECT_ID('dbo.Usuarios', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Usuarios (
        Id INT NOT NULL PRIMARY KEY,
        Login VARCHAR(50) NOT NULL,
        Senha VARCHAR(100) NOT NULL,
        Perfil VARCHAR(20) NOT NULL
    );
END
GO




-- Autentica
IF OBJECT_ID('dbo.spAutenticaUsuario', 'P') IS NOT NULL
    DROP PROCEDURE dbo.spAutenticaUsuario;
GO

CREATE PROCEDURE dbo.spAutenticaUsuario
    @login VARCHAR(50),
    @senha VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Id, Login, Senha, Perfil
    FROM dbo.Usuarios
    WHERE Login = @login AND Senha = @senha;
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Usuarios WHERE Login = 'admin')
    INSERT INTO dbo.Usuarios (Id, Login, Senha, Perfil) VALUES (1, 'admin', '1234', 'Admin');

IF NOT EXISTS (SELECT 1 FROM dbo.Usuarios WHERE Login = 'cliente')
    INSERT INTO dbo.Usuarios (Id, Login, Senha, Perfil) VALUES (2, 'cliente', '1234', 'Cliente');
GO