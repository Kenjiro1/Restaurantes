﻿/* =====================================================================
   Sistema de Restaurante (clientes, funcionários, cardápio e pedidos)
   Script do banco de dados. Execute no SQL Server Management Studio.
   Pode ser executado mais de uma vez.
   ===================================================================== */

IF DB_ID('RESTAURANTEDB') IS NULL
    CREATE DATABASE RESTAURANTEDB;
GO

USE RESTAURANTEDB;
GO

/* ---------------------------------------------------------------------
   TABELAS
   --------------------------------------------------------------------- */
IF OBJECT_ID('dbo.Clientes', 'U') IS NULL
CREATE TABLE Clientes
(
    id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    nome varchar(100) NOT NULL,
    cpf char(11) NOT NULL,                -- somente dígitos
    telefone varchar(11) NOT NULL,        -- somente dígitos (DDD + número)
    email varchar(100) NULL,
    CONSTRAINT UQ_Clientes_cpf UNIQUE (cpf)
)
GO

IF OBJECT_ID('dbo.Funcionarios', 'U') IS NULL
CREATE TABLE Funcionarios
(
    id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    nome varchar(100) NOT NULL,
    cargo varchar(50) NOT NULL,
    telefone varchar(11) NOT NULL,
    dataAdmissao datetime NOT NULL
)
GO

/* categoria: 1 = Entrada / 2 = Prato principal / 3 = Sobremesa / 4 = Bebida */
IF OBJECT_ID('dbo.Cardapio', 'U') IS NULL
CREATE TABLE Cardapio
(
    id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    nome varchar(100) NOT NULL,
    descricao varchar(300) NULL,
    categoria int NOT NULL,
    preco numeric(10,2) NOT NULL,
    ativo bit NOT NULL DEFAULT 1,
    CONSTRAINT CK_Cardapio_categoria CHECK (categoria IN (1, 2, 3, 4)),
    CONSTRAINT CK_Cardapio_preco CHECK (preco > 0)
)
GO

/* status: 1 = Aberto / 2 = Em preparo / 3 = Entregue / 4 = Cancelado */
IF OBJECT_ID('dbo.Pedidos', 'U') IS NULL
CREATE TABLE Pedidos
(
    id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    clienteId int NOT NULL,
    funcionarioId int NOT NULL,
    dataPedido datetime NOT NULL,
    status int NOT NULL,
    observacoes varchar(300) NULL,
    CONSTRAINT FK_Pedidos_Clientes FOREIGN KEY (clienteId) REFERENCES Clientes(id),
    CONSTRAINT FK_Pedidos_Funcionarios FOREIGN KEY (funcionarioId) REFERENCES Funcionarios(id),
    CONSTRAINT CK_Pedidos_status CHECK (status IN (1, 2, 3, 4))
)
GO

/* precoUnitario guarda o preço do item NO MOMENTO do pedido (o cardápio pode mudar depois) */
IF OBJECT_ID('dbo.ItensPedido', 'U') IS NULL
CREATE TABLE ItensPedido
(
    id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    pedidoId int NOT NULL,
    cardapioId int NOT NULL,
    quantidade int NOT NULL,
    precoUnitario numeric(10,2) NOT NULL,
    CONSTRAINT FK_ItensPedido_Pedidos FOREIGN KEY (pedidoId) REFERENCES Pedidos(id),
    CONSTRAINT FK_ItensPedido_Cardapio FOREIGN KEY (cardapioId) REFERENCES Cardapio(id),
    CONSTRAINT CK_ItensPedido_quantidade CHECK (quantidade > 0)
)
GO

/* ---------------------------------------------------------------------
   STORED PROCEDURES GENÉRICAS (usadas pela classe PadraoDAO)
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE spDelete
(
    @id int,
    @tabela varchar(max)
)
AS
BEGIN
    DECLARE @sql nvarchar(max) = N'delete from ' + QUOTENAME(@tabela) + N' where id = @id';
    EXEC sp_executesql @sql, N'@id int', @id = @id;
END
GO

CREATE OR ALTER PROCEDURE spConsulta
(
    @id int,
    @tabela varchar(max)
)
AS
BEGIN
    DECLARE @sql nvarchar(max) = N'select * from ' + QUOTENAME(@tabela) + N' where id = @id';
    EXEC sp_executesql @sql, N'@id int', @id = @id;
END
GO

CREATE OR ALTER PROCEDURE spListagem
(
    @tabela varchar(max),
    @ordem varchar(max)
)
AS
BEGIN
    DECLARE @sql nvarchar(max) = N'select * from ' + QUOTENAME(@tabela) + N' order by ' + @ordem;
    EXEC sp_executesql @sql;
END
GO

CREATE OR ALTER PROCEDURE spProximoId
(
    @tabela varchar(max)
)
AS
BEGIN
    DECLARE @sql nvarchar(max) = N'select isnull(max(id) + 1, 1) as MAIOR from ' + QUOTENAME(@tabela);
    EXEC sp_executesql @sql;
END
GO

/* Quantos registros dependem do registro informado (impede exclusões que quebrariam pedidos) */
CREATE OR ALTER PROCEDURE spEmUso
(
    @entidade varchar(30),
    @id int
)
AS
BEGIN
    IF @entidade = 'Clientes'
        SELECT COUNT(*) AS qtde FROM Pedidos WHERE clienteId = @id;
    ELSE IF @entidade = 'Funcionarios'
        SELECT COUNT(*) AS qtde FROM Pedidos WHERE funcionarioId = @id;
    ELSE IF @entidade = 'Cardapio'
        SELECT COUNT(*) AS qtde FROM ItensPedido WHERE cardapioId = @id;
    ELSE
        SELECT 0 AS qtde;
END
GO

/* ---------------------------------------------------------------------
   CLIENTES
   (o parâmetro @id existe só para manter o padrão da PadraoDAO; a chave é identity)
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE spInsert_Clientes
(
    @id int, @nome varchar(100), @cpf char(11), @telefone varchar(11), @email varchar(100)
)
AS
BEGIN
    INSERT INTO Clientes (nome, cpf, telefone, email) VALUES (@nome, @cpf, @telefone, @email);
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Clientes
(
    @id int, @nome varchar(100), @cpf char(11), @telefone varchar(11), @email varchar(100)
)
AS
BEGIN
    UPDATE Clientes SET nome = @nome, cpf = @cpf, telefone = @telefone, email = @email WHERE id = @id;
END
GO

CREATE OR ALTER PROCEDURE spConsultaClientePorCpf
(
    @cpf char(11)
)
AS
BEGIN
    SELECT * FROM Clientes WHERE cpf = @cpf;
END
GO

/* ---------------------------------------------------------------------
   FUNCIONÁRIOS
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE spInsert_Funcionarios
(
    @id int, @nome varchar(100), @cargo varchar(50), @telefone varchar(11), @dataAdmissao datetime
)
AS
BEGIN
    INSERT INTO Funcionarios (nome, cargo, telefone, dataAdmissao) VALUES (@nome, @cargo, @telefone, @dataAdmissao);
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Funcionarios
(
    @id int, @nome varchar(100), @cargo varchar(50), @telefone varchar(11), @dataAdmissao datetime
)
AS
BEGIN
    UPDATE Funcionarios SET nome = @nome, cargo = @cargo, telefone = @telefone, dataAdmissao = @dataAdmissao WHERE id = @id;
END
GO

/* ---------------------------------------------------------------------
   CARDÁPIO
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE spInsert_Cardapio
(
    @id int, @nome varchar(100), @descricao varchar(300), @categoria int, @preco numeric(10,2), @ativo bit
)
AS
BEGIN
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES (@nome, @descricao, @categoria, @preco, @ativo);
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Cardapio
(
    @id int, @nome varchar(100), @descricao varchar(300), @categoria int, @preco numeric(10,2), @ativo bit
)
AS
BEGIN
    UPDATE Cardapio SET nome = @nome, descricao = @descricao, categoria = @categoria, preco = @preco, ativo = @ativo WHERE id = @id;
END
GO

/* Itens disponíveis para serem pedidos */
CREATE OR ALTER PROCEDURE spListagemCardapioAtivos
AS
BEGIN
    SELECT * FROM Cardapio WHERE ativo = 1 ORDER BY categoria, nome;
END
GO

/* ---------------------------------------------------------------------
   PEDIDOS
   --------------------------------------------------------------------- */

/* View com o pedido já "junto" com cliente, funcionário e valor total calculado dos itens */
CREATE OR ALTER VIEW vwPedidos
AS
SELECT p.id, p.clienteId, p.funcionarioId, p.dataPedido, p.status, p.observacoes,
       c.nome AS nomeCliente,
       f.nome AS nomeFuncionario,
       ISNULL(t.qtdItens, 0) AS qtdItens,
       ISNULL(t.valorTotal, 0) AS valorTotal
FROM Pedidos p
INNER JOIN Clientes c ON c.id = p.clienteId
INNER JOIN Funcionarios f ON f.id = p.funcionarioId
LEFT JOIN (SELECT pedidoId,
                  SUM(quantidade) AS qtdItens,
                  SUM(quantidade * precoUnitario) AS valorTotal
           FROM ItensPedido
           GROUP BY pedidoId) t ON t.pedidoId = p.id
GO

CREATE OR ALTER PROCEDURE spInsert_Pedidos
(
    @id int, @clienteId int, @funcionarioId int, @dataPedido datetime, @status int, @observacoes varchar(300)
)
AS
BEGIN
    INSERT INTO Pedidos (clienteId, funcionarioId, dataPedido, status, observacoes)
    VALUES (@clienteId, @funcionarioId, @dataPedido, @status, @observacoes);
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Pedidos
(
    @id int, @clienteId int, @funcionarioId int, @dataPedido datetime, @status int, @observacoes varchar(300)
)
AS
BEGIN
    UPDATE Pedidos SET clienteId = @clienteId, funcionarioId = @funcionarioId, dataPedido = @dataPedido,
                       status = @status, observacoes = @observacoes
    WHERE id = @id;
END
GO

CREATE OR ALTER PROCEDURE spConsultaPedido
(
    @id int
)
AS
BEGIN
    SELECT * FROM vwPedidos WHERE id = @id;
END
GO

/* Consulta de pedidos com filtros. Para os filtros numéricos, 0 = todos.
   @dataFinal é EXCLUSIVA (o sistema envia o dia seguinte ao escolhido). */
CREATE OR ALTER PROCEDURE spConsultaPedidos
(
    @dataInicial datetime,
    @dataFinal datetime,
    @status int,
    @clienteId int,
    @funcionarioId int
)
AS
BEGIN
    SELECT *
    FROM vwPedidos
    WHERE dataPedido >= @dataInicial
      AND dataPedido < @dataFinal
      AND (@status = 0 OR status = @status)
      AND (@clienteId = 0 OR clienteId = @clienteId)
      AND (@funcionarioId = 0 OR funcionarioId = @funcionarioId)
    ORDER BY dataPedido DESC, id DESC;
END
GO

CREATE OR ALTER PROCEDURE spExcluiPedido
(
    @id int
)
AS
BEGIN
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
        DELETE FROM ItensPedido WHERE pedidoId = @id;
        DELETE FROM Pedidos WHERE id = @id;
    COMMIT TRANSACTION;
END
GO

/* ---------------------------------------------------------------------
   ITENS DO PEDIDO
   --------------------------------------------------------------------- */

/* O preço do item é sempre lido do cardápio (o @precoUnitario recebido é ignorado).
   Se o item já estiver no pedido, apenas soma a quantidade. */
CREATE OR ALTER PROCEDURE spInsert_ItensPedido
(
    @id int, @pedidoId int, @cardapioId int, @quantidade int, @precoUnitario numeric(10,2)
)
AS
BEGIN
    DECLARE @preco numeric(10,2) = (SELECT preco FROM Cardapio WHERE id = @cardapioId);

    IF EXISTS (SELECT 1 FROM ItensPedido WHERE pedidoId = @pedidoId AND cardapioId = @cardapioId)
        UPDATE ItensPedido SET quantidade = quantidade + @quantidade
        WHERE pedidoId = @pedidoId AND cardapioId = @cardapioId;
    ELSE
        INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario)
        VALUES (@pedidoId, @cardapioId, @quantidade, @preco);
END
GO

CREATE OR ALTER PROCEDURE spUpdate_ItensPedido
(
    @id int, @pedidoId int, @cardapioId int, @quantidade int, @precoUnitario numeric(10,2)
)
AS
BEGIN
    UPDATE ItensPedido SET quantidade = @quantidade WHERE id = @id;
END
GO

CREATE OR ALTER PROCEDURE spItensDoPedido
(
    @pedidoId int
)
AS
BEGIN
    SELECT i.id, i.pedidoId, i.cardapioId, i.quantidade, i.precoUnitario, c.nome AS nomeItem
    FROM ItensPedido i
    INNER JOIN Cardapio c ON c.id = i.cardapioId
    WHERE i.pedidoId = @pedidoId
    ORDER BY i.id;
END
GO

/* ---------------------------------------------------------------------
   CONSULTAS DE ANÁLISE (pedidos cancelados não entram nas somas)
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE spItensMaisVendidos
(
    @dataInicial datetime,
    @dataFinal datetime,
    @top int
)
AS
BEGIN
    SELECT TOP (@top)
           c.id AS cardapioId,
           c.nome,
           SUM(i.quantidade) AS quantidadeVendida,
           SUM(i.quantidade * i.precoUnitario) AS faturamento
    FROM ItensPedido i
    INNER JOIN Pedidos p ON p.id = i.pedidoId
    INNER JOIN Cardapio c ON c.id = i.cardapioId
    WHERE p.status <> 4
      AND p.dataPedido >= @dataInicial
      AND p.dataPedido < @dataFinal
    GROUP BY c.id, c.nome
    ORDER BY quantidadeVendida DESC, faturamento DESC;
END
GO

CREATE OR ALTER PROCEDURE spFaturamentoPorFuncionario
(
    @dataInicial datetime,
    @dataFinal datetime
)
AS
BEGIN
    SELECT f.id AS funcionarioId,
           f.nome,
           COUNT(DISTINCT p.id) AS qtdPedidos,
           ISNULL(SUM(i.quantidade * i.precoUnitario), 0) AS faturamento
    FROM Pedidos p
    INNER JOIN Funcionarios f ON f.id = p.funcionarioId
    LEFT JOIN ItensPedido i ON i.pedidoId = p.id
    WHERE p.status <> 4
      AND p.dataPedido >= @dataInicial
      AND p.dataPedido < @dataFinal
    GROUP BY f.id, f.nome
    ORDER BY faturamento DESC;
END
GO

/* ---------------------------------------------------------------------
   DADOS DE EXEMPLO (somente se o banco estiver vazio)
   --------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM Clientes) AND NOT EXISTS (SELECT 1 FROM Funcionarios)
   AND NOT EXISTS (SELECT 1 FROM Cardapio) AND NOT EXISTS (SELECT 1 FROM Pedidos)
BEGIN
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;

    INSERT INTO Clientes (nome, cpf, telefone, email) VALUES ('Ana Paula Silva', '52998224725', '11987654321', 'ana.silva@email.com');
    INSERT INTO Clientes (nome, cpf, telefone, email) VALUES ('Bruno Costa', '11144477735', '21912345678', NULL);
    INSERT INTO Clientes (nome, cpf, telefone, email) VALUES ('Carla Mendes', '12345678909', '3133334444', 'carla@email.com');

    INSERT INTO Funcionarios (nome, cargo, telefone, dataAdmissao) VALUES ('Marcos Oliveira', 'Garçom', '11988887777', '20220315');
    INSERT INTO Funcionarios (nome, cargo, telefone, dataAdmissao) VALUES ('Juliana Rocha', 'Atendente', '11977776666', '20230801');

    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Bruschetta', 'Pão italiano com tomate e manjericão', 1, 22.00, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Salada Caesar', 'Alface, frango grelhado, parmesão e croutons', 1, 28.50, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Lasanha à Bolonhesa', 'Massa fresca, molho bolonhesa e queijos', 2, 46.90, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Filé com Fritas', 'Filé mignon grelhado com batatas fritas', 2, 59.90, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Petit Gâteau', 'Bolo quente de chocolate com sorvete', 3, 24.90, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Suco Natural', 'Laranja, limão ou maracujá (500 ml)', 4, 12.00, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Refrigerante Lata', '350 ml', 4, 7.50, 1);
    INSERT INTO Cardapio (nome, descricao, categoria, preco, ativo) VALUES ('Risoto de Camarão', 'Prato sazonal (temporariamente fora do cardápio)', 2, 68.00, 0);

    DECLARE @cli1 int = (SELECT id FROM Clientes WHERE cpf = '52998224725');
    DECLARE @cli2 int = (SELECT id FROM Clientes WHERE cpf = '11144477735');
    DECLARE @cli3 int = (SELECT id FROM Clientes WHERE cpf = '12345678909');
    DECLARE @fun1 int = (SELECT id FROM Funcionarios WHERE nome = 'Marcos Oliveira');
    DECLARE @fun2 int = (SELECT id FROM Funcionarios WHERE nome = 'Juliana Rocha');
    DECLARE @p int;

    -- Pedido entregue (há 3 dias)
    INSERT INTO Pedidos (clienteId, funcionarioId, dataPedido, status, observacoes) VALUES (@cli1, @fun1, DATEADD(DAY, -3, GETDATE()), 3, NULL);
    SET @p = SCOPE_IDENTITY();
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 1, preco FROM Cardapio WHERE nome = 'Lasanha à Bolonhesa';
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 2, preco FROM Cardapio WHERE nome = 'Suco Natural';

    -- Pedido entregue (há 2 dias)
    INSERT INTO Pedidos (clienteId, funcionarioId, dataPedido, status, observacoes) VALUES (@cli2, @fun2, DATEADD(DAY, -2, GETDATE()), 3, 'Sem cebola');
    SET @p = SCOPE_IDENTITY();
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 2, preco FROM Cardapio WHERE nome = 'Filé com Fritas';
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 2, preco FROM Cardapio WHERE nome = 'Refrigerante Lata';
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 1, preco FROM Cardapio WHERE nome = 'Petit Gâteau';

    -- Pedido cancelado (ontem)
    INSERT INTO Pedidos (clienteId, funcionarioId, dataPedido, status, observacoes) VALUES (@cli3, @fun1, DATEADD(DAY, -1, GETDATE()), 4, 'Cliente desistiu');
    SET @p = SCOPE_IDENTITY();
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 1, preco FROM Cardapio WHERE nome = 'Salada Caesar';

    -- Pedido em preparo (hoje)
    INSERT INTO Pedidos (clienteId, funcionarioId, dataPedido, status, observacoes) VALUES (@cli1, @fun2, GETDATE(), 2, NULL);
    SET @p = SCOPE_IDENTITY();
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 1, preco FROM Cardapio WHERE nome = 'Bruschetta';
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 1, preco FROM Cardapio WHERE nome = 'Lasanha à Bolonhesa';
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 1, preco FROM Cardapio WHERE nome = 'Suco Natural';

    -- Pedido aberto (hoje)
    INSERT INTO Pedidos (clienteId, funcionarioId, dataPedido, status, observacoes) VALUES (@cli3, @fun1, GETDATE(), 1, 'Mesa 5');
    SET @p = SCOPE_IDENTITY();
    INSERT INTO ItensPedido (pedidoId, cardapioId, quantidade, precoUnitario) SELECT @p, id, 2, preco FROM Cardapio WHERE nome = 'Lasanha à Bolonhesa';

    COMMIT TRANSACTION;
END
GO