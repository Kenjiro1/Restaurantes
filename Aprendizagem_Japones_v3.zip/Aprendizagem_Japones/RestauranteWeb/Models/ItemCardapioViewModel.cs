namespace RestauranteWeb.Models
{
    public class ItemCardapioViewModel : PadraoViewModel
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public int Categoria { get; set; }

        public decimal Preco { get; set; }
        public bool Ativo { get; set; }

        public string DescricaoCategoria
        {
            get { return Opcoes.DescricaoCategoria(Categoria); }
        }
    }
}
