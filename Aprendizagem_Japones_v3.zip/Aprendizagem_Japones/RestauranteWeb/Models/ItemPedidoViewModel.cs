namespace RestauranteWeb.Models
{
    public class ItemPedidoViewModel : PadraoViewModel
    {
        public int PedidoId { get; set; }

        public int CardapioId { get; set; }

        public int Quantidade { get; set; }
        public decimal PrecoUnitario { get; set; }
        public string NomeItem { get; set; }

        public decimal Subtotal
        {
            get { return Quantidade * PrecoUnitario; }
        }
    }
}
