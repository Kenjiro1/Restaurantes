using System;

namespace RestauranteWeb.Models
{
    public class FuncionarioViewModel : PadraoViewModel
    {
        public string Nome { get; set; }

        public string Cargo { get; set; }
        public string Telefone { get; set; }

        public DateTime DataAdmissao { get; set; }
    }
}
