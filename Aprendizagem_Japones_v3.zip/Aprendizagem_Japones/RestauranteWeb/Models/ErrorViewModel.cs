namespace RestauranteWeb.Models
{
    public class ErrorViewModel
    {
        public ErrorViewModel(string erro)
        {
            Erro = erro;
        }

        public ErrorViewModel()
        {
        }

        public string Erro { get; set; }
    }
}
