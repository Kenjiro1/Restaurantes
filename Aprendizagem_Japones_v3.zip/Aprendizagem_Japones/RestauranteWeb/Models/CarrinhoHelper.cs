﻿using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Microsoft.AspNetCore.Http;

namespace RestauranteWeb.Models
{
    public class ItemCarrinhoViewModel
    {
        public int PratoId { get; set; }
        public string NomePrato { get; set; } = string.Empty;
        public decimal PrecoUnitario { get; set; }
        public int Quantidade { get; set; }
        public decimal Subtotal => PrecoUnitario * Quantidade;
    }

    public static class CarrinhoHelper
    {
        private const string ChaveCarrinho = "Carrinho";

        public static List<ItemCarrinhoViewModel> ObterCarrinho(ISession session)
        {
            string? json = session.GetString(ChaveCarrinho);
            if (string.IsNullOrWhiteSpace(json))
                return new List<ItemCarrinhoViewModel>();

            return JsonSerializer.Deserialize<List<ItemCarrinhoViewModel>>(json)
                   ?? new List<ItemCarrinhoViewModel>();
        }

        public static void SalvarCarrinho(ISession session, List<ItemCarrinhoViewModel> itens)
        {
            string json = JsonSerializer.Serialize(itens);
            session.SetString(ChaveCarrinho, json);
        }

        public static void AdicionarItem(ISession session, ItemCarrinhoViewModel novoItem)
        {
            var carrinho = ObterCarrinho(session);
            var existente = carrinho.FirstOrDefault(x => x.PratoId == novoItem.PratoId);

            if (existente != null)
                existente.Quantidade += novoItem.Quantidade;
            else
                carrinho.Add(novoItem);

            SalvarCarrinho(session, carrinho);
        }

        public static void RemoverItem(ISession session, int pratoId)
        {
            var carrinho = ObterCarrinho(session);
            carrinho.RemoveAll(x => x.PratoId == pratoId);
            SalvarCarrinho(session, carrinho);
        }

        public static void LimparCarrinho(ISession session)
        {
            session.Remove(ChaveCarrinho);
        }
    }
}