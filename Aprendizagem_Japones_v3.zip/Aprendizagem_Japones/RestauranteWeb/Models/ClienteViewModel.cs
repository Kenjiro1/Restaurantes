namespace RestauranteWeb.Models
{
    public class ClienteViewModel : PadraoViewModel
    {
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
    }
}
