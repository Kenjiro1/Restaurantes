using System.Collections.Generic;
using System.Linq;

namespace RestauranteWeb.Models
{
    public static class Opcoes
    {
        public const int StatusAberto = 1;
        public const int StatusEmPreparo = 2;
        public const int StatusEntregue = 3;
        public const int StatusCancelado = 4;

        public static readonly Dictionary<int, string> StatusPedido = new Dictionary<int, string>
        {
            { StatusAberto, "Aberto" },
            { StatusEmPreparo, "Em preparo" },
            { StatusEntregue, "Entregue" },
            { StatusCancelado, "Cancelado" }
        };

        public static readonly Dictionary<int, string> CategoriasCardapio = new Dictionary<int, string>
        {
            { 1, "Entrada" },
            { 2, "Prato principal" },
            { 3, "Sobremesa" },
            { 4, "Bebida" }
        };

        public static string DescricaoStatus(int status)
        {
            return StatusPedido.TryGetValue(status, out string d) ? d : string.Empty;
        }

        public static string DescricaoCategoria(int categoria)
        {
            return CategoriasCardapio.TryGetValue(categoria, out string d) ? d : string.Empty;
        }

        /// <summary>Só os itens de pedidos Abertos ou Em preparo podem ser alterados</summary>
        public static bool PedidoPermiteAlterarItens(int status)
        {
            return status == StatusAberto || status == StatusEmPreparo;
        }

        // ---------- Utilitários de texto ----------
        public static string SoDigitos(string texto)
        {
            return new string((texto ?? string.Empty).Where(char.IsDigit).ToArray());
        }

        public static bool CpfValido(string cpf)
        {
            string d = SoDigitos(cpf);
            if (d.Length != 11 || d.Distinct().Count() == 1)
                return false;

            int[] n = d.Select(c => c - '0').ToArray();

            int soma = 0;
            for (int i = 0; i < 9; i++)
                soma += n[i] * (10 - i);
            int r = (soma * 10) % 11;
            if (r == 10) r = 0;
            if (r != n[9]) return false;

            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += n[i] * (11 - i);
            r = (soma * 10) % 11;
            if (r == 10) r = 0;
            return r == n[10];
        }

        public static string FormataCpf(string cpf)
        {
            string d = SoDigitos(cpf);
            if (d.Length != 11) return cpf;
            return d.Substring(0, 3) + "." + d.Substring(3, 3) + "." + d.Substring(6, 3) + "-" + d.Substring(9, 2);
        }

        public static string FormataTelefone(string telefone)
        {
            string d = SoDigitos(telefone);
            if (d.Length == 11)
                return "(" + d.Substring(0, 2) + ") " + d.Substring(2, 5) + "-" + d.Substring(7, 4);
            if (d.Length == 10)
                return "(" + d.Substring(0, 2) + ") " + d.Substring(2, 4) + "-" + d.Substring(6, 4);
            return telefone;
        }
    }
}
