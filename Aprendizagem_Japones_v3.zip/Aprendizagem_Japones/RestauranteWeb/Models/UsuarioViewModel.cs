﻿using RestauranteWeb.Models;

namespace RestauranteWeb.Models
{
    public class UsuarioViewModel : PadraoViewModel
    {
        public string Login { get; set; } = string.Empty;
        public string Senha { get; set; } = string.Empty;
        public string Perfil { get; set; } = string.Empty; // Ex.: "Admin" ou "Cliente"
    }
}