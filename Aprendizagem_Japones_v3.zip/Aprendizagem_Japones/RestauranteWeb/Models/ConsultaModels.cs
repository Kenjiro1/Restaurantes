using System.Collections.Generic;
using System.Linq;

namespace RestauranteWeb.Models
{
    public class ConsultaPedidosResultado
    {
        public int QuantidadePedidos { get; set; }
        public decimal ValorTotal { get; set; }

        public List<PedidoViewModel> Pedidos { get; set; } = new List<PedidoViewModel>();

        public static ConsultaPedidosResultado De(List<PedidoViewModel> pedidos)
        {
            return new ConsultaPedidosResultado
            {
                Pedidos = pedidos,
                QuantidadePedidos = pedidos.Count,
                ValorTotal = pedidos.Where(p => p.Status != Opcoes.StatusCancelado).Sum(p => p.ValorTotal)
            };
        }
    }

    public class ItemMaisVendidoViewModel
    {
        public int CardapioId { get; set; }
        public string Nome { get; set; }
        public int QuantidadeVendida { get; set; }
        public decimal Faturamento { get; set; }
    }

    public class FaturamentoFuncionarioViewModel
    {
        public int FuncionarioId { get; set; }
        public string Nome { get; set; }
        public int QtdPedidos { get; set; }
        public decimal Faturamento { get; set; }
    }
    public class AlteraStatusRequest
    {
        public int Status { get; set; }
    }
    public class ErroApiModel
    {
        public ErroApiModel()
        {
        }

        public ErroApiModel(string mensagem, Dictionary<string, string> erros = null)
        {
            Mensagem = mensagem;
            Erros = erros;
        }

        public string Mensagem { get; set; }

        /// <summary>Erros por campo (quando for erro de validação)</summary>
        public Dictionary<string, string> Erros { get; set; }
    }
}
