using System;
using System.Collections.Generic;

namespace RestauranteWeb.Models
{
    public class PedidoViewModel : PadraoViewModel
    {
        public int ClienteId { get; set; }

        public int FuncionarioId { get; set; }

        public DateTime DataPedido { get; set; }
        public int Status { get; set; }
        public string Observacoes { get; set; }
        public string NomeCliente { get; set; }
        public string NomeFuncionario { get; set; }
        public int QtdItens { get; set; }
        public decimal ValorTotal { get; set; }

        public string DescricaoStatus
        {
            get { return Opcoes.DescricaoStatus(Status); }
        }

        /// <summary>Itens do pedido. Pode ser enviado na criação de um pedido pela API.</summary>
        public List<ItemPedidoViewModel> Itens { get; set; } = new List<ItemPedidoViewModel>();
    }
}
