using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers
{
    /// <summary>
    /// Controller padrão para CRUDs: os controllers filhos só informam a DAO,
    /// as validações específicas e, se precisarem, os dados extras das telas[cite: 3, 64].
    /// </summary>
    public abstract class PadraoController<T> : Controller where T : PadraoViewModel
    {
        protected PadraoDAO<T> DAO { get; set; }

        protected string NomeViewIndex { get; set; } = "Index";
        protected string NomeViewForm { get; set; } = "Form";

        /// <summary>Define se o controller exige usuário autenticado na sessão.</summary>
        protected bool ExigeAutenticacao { get; set; } = true;

        /// <summary>Define se o controller exige perfil de Administrador ("Admin").</summary>
        protected bool ExigeAdmin { get; set; } = false;

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            bool logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
            string perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);

            if (ExigeAutenticacao && !logado)
            {
                context.Result = RedirectToAction("Index", "Login");
                return;
            }

            ViewBag.Logado = logado;
            ViewBag.Perfil = perfil;

            if (ExigeAdmin && !HelperControllers.EhAdmin(HttpContext.Session))
            {
                context.Result = RedirectToAction("Index", "Home");
                return;
            }

            base.OnActionExecuting(context);
        }

        public virtual IActionResult Index()
        {
            try
            {
                return View(NomeViewIndex, DAO.Listagem());
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public virtual IActionResult Create()
        {
            try
            {
                ViewBag.Operacao = "I";
                T model = Activator.CreateInstance<T>();
                PreencheDadosParaView("I", model);
                return View(NomeViewForm, model);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        /// <summary>Dados extras que o formulário precisa (combos, valores padrão...)</summary>
        protected virtual void PreencheDadosParaView(string operacao, T model)
        {
        }

        public virtual IActionResult Salvar(T model, string Operacao)
        {
            try
            {
                ValidaDados(model, Operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = Operacao;
                    PreencheDadosParaView(Operacao, model);
                    return View(NomeViewForm, model);
                }

                if (Operacao == "I")
                    model.Id = DAO.Insert(model); // devolve o id gerado (identity)[cite: 89]
                else
                    DAO.Update(model);

                return RedirecionaAposSalvar(model, Operacao);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        /// <summary>Para onde ir depois de salvar. Os filhos podem sobrescrever.</summary>
        protected virtual IActionResult RedirecionaAposSalvar(T model, string operacao)
        {
            return RedirectToAction("Index");
        }

        protected virtual void ValidaDados(T model, string operacao)
        {
            // limpa os erros automáticos do ASP.NET (mensagens em inglês); usamos os nossos[cite: 49, 65]
            ModelState.Clear();

            if (operacao != "I" && (model.Id <= 0 || DAO.Consulta(model.Id) == null))
                ModelState.AddModelError("Id", "Este registro não existe!");
        }

        /// <summary>Transfere o resultado dos validadores (campo -> mensagem) para o ModelState</summary>
        protected void AdicionaErros(Dictionary<string, string> erros)
        {
            foreach (var erro in erros)
                ModelState.AddModelError(erro.Key, erro.Value);
        }

        public virtual IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Operacao = "A";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction("Index");

                PreencheDadosParaView("A", model);
                return View(NomeViewForm, model);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public virtual IActionResult Delete(int id)
        {
            try
            {
                DAO.Delete(id);
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
    }
}