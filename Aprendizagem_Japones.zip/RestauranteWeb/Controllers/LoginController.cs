﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;

namespace RestauranteWeb.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
            ViewBag.Perfil = HelperControllers.ObtemPerfilUsuario(HttpContext.Session);
            return View();
        }

        [HttpPost]
        public IActionResult FazLogin(string usuario, string senha)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(senha))
                {
                    ViewBag.Erro = "Informe o usuário e a senha.";
                    return View("Index");
                }

                UsuarioDAO usuarioDao = new UsuarioDAO();
                UsuarioViewModel? usuarioEncontrado = usuarioDao.Autenticar(usuario.Trim(), senha);

                if (usuarioEncontrado != null)
                {
                    HttpContext.Session.SetString("Logado", "true");
                    HttpContext.Session.SetString("Perfil", usuarioEncontrado.Perfil);
                    HttpContext.Session.SetString("UsuarioLogin", usuarioEncontrado.Login);

                    // Prepara o redirecionamento conforme o perfil (Etapa 2: Home Admin x Home Cliente)
                    if (string.Equals(usuarioEncontrado.Perfil, "Admin", StringComparison.OrdinalIgnoreCase))
                        return RedirectToAction("Index", "Home");

                    return RedirectToAction("Index", "Home");
                }

                ViewBag.Erro = "Usuário ou senha inválidos!";
                return View("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }

        public IActionResult LogOff()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}