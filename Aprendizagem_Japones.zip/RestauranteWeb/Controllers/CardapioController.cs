using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;
using RestauranteWeb.Validation;

namespace RestauranteWeb.Controllers
{
    public class CardapioController : PadraoController<ItemCardapioViewModel>
    {
        public CardapioController()
        {
            DAO = new CardapioDAO();
        }

        protected override void PreencheDadosParaView(string operacao, ItemCardapioViewModel model)
        {
            // Novo item já nasce disponível
            if (operacao == "I" && Request.Method == "GET")
                model.Ativo = true;
        }

        protected override void ValidaDados(ItemCardapioViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);
            AdicionaErros(CardapioValidador.Valida(model));
        }

        public override IActionResult Delete(int id)
        {
            try
            {
                if (((CardapioDAO)DAO).EmUso(id))
                    return View("Error", new ErrorViewModel(
                        "Este item já foi usado em pedidos e não pode ser excluído. Edite o item e marque-o como indisponível."));
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
            return base.Delete(id);
        }
    }
}
