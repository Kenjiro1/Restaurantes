using Microsoft.AspNetCore.Mvc;
using RestauranteWeb.DAO;
using RestauranteWeb.Models;
using RestauranteWeb.Validation;

namespace RestauranteWeb.Controllers
{
    public class FuncionarioController : PadraoController<FuncionarioViewModel>
    {
        public FuncionarioController()
        {
            DAO = new FuncionarioDAO();
        }

        protected override void ValidaDados(FuncionarioViewModel model, string operacao)
        {
            base.ValidaDados(model, operacao);
            AdicionaErros(FuncionarioValidador.Valida(model));
        }

        public override IActionResult Delete(int id)
        {
            try
            {
                if (((FuncionarioDAO)DAO).EmUso(id))
                    return View("Error", new ErrorViewModel("Não é possível excluir este funcionário, pois ele possui pedidos atendidos."));
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
            return base.Delete(id);
        }
    }
}
